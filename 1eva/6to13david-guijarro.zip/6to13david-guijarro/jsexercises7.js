// 7.- Write a for loop that iterates from 0 to 10. For each iteration, multiply the number by 9 and log the result (e.g., “2 * 9 = 18”).

var a = 0
while (a < 11) {
    op = 0
    op = a * 9
    console.log(a , "* 9 = ", op);
    a++;
}