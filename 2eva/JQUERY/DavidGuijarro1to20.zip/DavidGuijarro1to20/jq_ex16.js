$(document).ready(function() {
    $("#myBtn").click(function() {
        $(this).text("Text Changed!");
    });
});