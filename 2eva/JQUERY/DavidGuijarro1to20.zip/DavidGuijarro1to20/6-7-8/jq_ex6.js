$(document).ready(function() {
    $("button").insertBefore("p:first");
});