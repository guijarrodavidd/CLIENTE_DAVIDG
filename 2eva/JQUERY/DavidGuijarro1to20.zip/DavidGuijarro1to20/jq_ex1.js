$(document).ready(function() {
    console.log($("p"));
    console.log($("#todo-list"));
    console.log($("p, li.b"));
    console.log($("*"));
    console.log($("#important.a"));
    console.log($("ul+p"));
    console.log($("p"));
    console.log($("p"));
    console.log($("p"));
});


